ART BOOK NEXT + HLTB MAIN STORY
================================

INSTALL
-------
Extract this ZIP directly into:

  /storage/roms

The archive contains:

  themes/art-book-next-es/
  ports/Art Book Next - Sync HLTB.sh

The Ports launcher is self-contained; its HLTB synchronizer is embedded.

USAGE
-----
1. In EmulationStation, select the "art-book-next-es" theme.
2. Refresh/update the game list if the new Ports entry is not visible.
3. Open Ports and run "Art Book Next - Sync HLTB".
4. EmulationStation will restart automatically after the sync.

The Detailed view displays "Avg. Main Story" using HLTB's main_story data.
Games without a safe HLTB title match display "Unknown".

Run the Ports entry again after adding or renaming games. The HLTB CSV is
downloaded once and cached in /storage/.cache/art-book-next-hltb/.

Backups are created beside changed gamelist.xml files with the suffix:

  .bak-before-main-story

Logs and the latest status are stored in:

  /storage/roms/ports/art-book-next-hltb/sync.log
  /storage/roms/ports/art-book-next-hltb/last-status.txt
